function create()
    -- https://kadedev.github.io/Avg4KModDocs/
    -- https://stackoverflow.com/questions/20423406/lua-convert-string-to-table
    -- https://wiki.libsdl.org/SDL2/SDLKeycodeLookup

        -- This dofile runs spriteFrame
    dofile(formCompletePath("spriteFrame.lua"))
    SpriteFrame.create() -- this inits the classes

    -- init variables
    bpm = 120
    sentence = "you cant spell among without og" -- string to be typed
    sentencelen = #sentence
    consolePrint(sentence)
    consolePrint("string length: " .. sentencelen)
    currentIndex = 1 -- current character
    score = 0 -- total characters correct
    keys = 0 -- total characters typed
    over = false -- is the game over
    start = false -- has the first key been pressed
    check = false -- checks if it did the update loop
    converted = {} -- array to hold characters

    s = "[in code]"
    consolePrint(string.sub(s, 2, -2))

    -- converts str to SDL keycode using reference array and puts each character in the `t` array
    reference = {a = 97, b = 98, c = 99, d = 100, e = 101, f = 102, g = 103, h = 104, i = 105, j = 106,
        k = 107, l = 108, m = 109, n = 110, o = 111, p = 112, q = 113, r = 114, s = 115, t = 116, u = 117,
        v = 118, w = 119, x = 120, y = 121, z = 122, [" "]= 32}

    -- array with the characters, unconverted; used for making sprites
    characters = {}
    for i = 1, sentencelen do
        -- consolePrint("i is: " .. i .. " char?: " .. string.sub(sentence, i, i))
        characters[#characters+1] = string.sub(sentence, i, i)
    end

    -- array with the converted keycodes to check in key_pressed() event
    for i = 1, sentencelen do
        consolePrint("i is: " .. i .. " char?: " .. string.sub(sentence, i, i))
        keycode = reference[sentence:sub(i, i):lower()]
        if keycode then
            converted[i] = keycode
        end
    end


    function dump(o)
        if type(o) == 'table' then
           local s = '{ '
           for k,v in pairs(o) do
              if type(k) ~= 'number' then k = '"'..k..'"' end
              s = s .. '['..k..'] = ' .. dump(v) .. ','
           end
           return s .. '} '
        else
           return tostring(o)
        end
     end

    consolePrint(dump(characters))
    consolePrint(dump(converted))

    local textsprites = {}
    -- create a sprite for each of the character
    for i = 1, sentencelen do
        -- change "i*30" to the spacing of the characters when i find out the img size
        -- consolePrint("i is: " .. i .. " char?: " .. string.sub(sentence, i, i))
        characters[#characters+1] = string.sub(sentence, i, i)

        -- Ctext object named "text"+i, font "arial", text of `string.sub(sentence, i, i)`, size of 24, position 20, 20
        _G["text" .. i] = Text:new("text" .. i, "arial", string.sub(sentence, i, i), 50, i*40+200, 500)
        -- createSprite(characters[i], "sprite" .. i, i*30, 0)
    end

    -- creates a sprite at 200,200 named "mySprite" with the file "sprite.png" in the mod folder
    selector = Sprite:new('selector','selector', 220, 495)

    -- move the receptors offscreen
    -- activateMod("amovey", 0, 0, "outCubic", -100000)

end

function key_pressed(key)
    consolePrint("Key pressed! " .. key)
    -- starts timer on first key press
    if start == false then
        time_start = getTime()
        consolePrint("START TIME: " .. time_start)
        start = true
    end

    -- is the game over
    if over == false then

        -- checks if the array is not empty and the character pressed matches the current character in the array
        if currentIndex < #converted then
            -- consolePrint("press " .. converted[currentIndex])
            if key == converted[currentIndex] then
                -- do something, like print a message
                -- consolePrint("Key pressed matches array value")
                score = score + 1
                -- remove the current element from the table
                -- table.remove(converted, currentIndex)
            end
            keys = keys + 1
            currentIndex = currentIndex + 1

            for i = 1, sentencelen do
                _G["text" .. i].x = _G["text" .. i].x - 40
            end

        else
            over = true
            -- handle the case when the table is empty, aka the sentence has been typed
            accuracy = (score/keys) * 100
            accuracy = math.floor(accuracy*100)/100
            consolePrint("Your accuracy was: " .. accuracy .. "%")
            textacc = Text:new("textacc", "arial", "Accuracy: " .. accuracy .. "%", 50, 300, 250)
        end
    else 
        -- what
    end
end

function update(beat)

    SpriteFrame.update() -- updates sprites
    selector.x = 220
    selector.y = 495
    -- if the game is over and it hasn't calculated time yet, calculate the time it took to type the sentence
    if over then
        if check == false then
            time_end = getTime()
            consolePrint("END TIME: " .. time_end)
            time = (time_end - time_start) / 1000
            time = math.floor(time*100)/100
            consolePrint("Elapsed time: " .. time .. " seconds")
            texttime = Text:new("texttime", "arial", "Elapsed time: " .. time .. "s", 50, 300, 200)
            check = true
        end
    end
end