function create()
    -- This dofile runs modFrame
    dofile(formCompletePath("modFrame.lua"))

    ModFrame.create() -- this creates all the mods we can use

    local scrollspeed = config.scrollSpeed


    for i = 0, 3 do
        activateModMap("reverse", 0.1, 0.1, "outcubic", 1, i)
    end


    for i = 2, 1000 do
        set{'cmod', scrollspeed, i*2}
        set{'cmod', 100, i*2 + 1}
    end

    -- use a se (shader ease) (on beat 4, over 1 beats in length. set the value of aberration in the shader to 1 from 0)
    -- shader{'aberration','NULL','aberration', {{'aberration', 0}}}
    -- shaderTarget('camera','aberration')
    -- se{'aberration', 0, 1, 0, 0,'aberration','outCubic'}
    

end

function editor_scroll() -- for previewing in the mod editor
    ModFrame.editor_scroll()
end

function update(beat) -- actually run our mods
    ModFrame.update(beat)
end