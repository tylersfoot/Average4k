function create()
	createSprite("BA", "BA", 0, 0)
	setSpriteProperty("BA", "sparrow", "BA")
	setSpriteProperty("BA", "loop", "true")
	setSpriteProperty("BA", "fps", "60")
	setSpriteProperty("BA", "anim", "BA")
end

function update()
	-- bruh
end